<?php

/**
 * @package         Google Structured Data
 * @version         6.2.0 Pro
 *
 * @author          Tassos Marinos <info@tassos.gr>
 * @link            http://www.tassos.gr
 * @copyright       Copyright © 2026 Tassos Marinos All Rights Reserved
 * @license         GNU GPLv3 <http://www.gnu.org/licenses/gpl.html> or later
 */

defined('_JEXEC') or die;

require_once __DIR__ . '/script.install.helper.php';

class PlgGSDDJClassifiedsInstallerScript extends PlgGSDDJClassifiedsInstallerScriptHelper
{
    public $alias = 'djclassifieds';
    public $extension_type = 'plugin';
    public $plugin_folder = 'gsd';
    public $show_message = false;
    public $autopublish = false;
}