<?php
/**
 * @package     Yootheme Pro Translate for Joomla!
 * @author      Stéphane Bouey <stephane.bouey@faboba.com> - http://www.faboba.com
 * @license     GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 * @copyright   Copyright (C) 2012-2024 Faboba. All rights reserved.
*/

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Form\Form;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Uri\Uri;
use Joomla\Database\DatabaseInterface;
use YOOtheme\Application;

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

//yootheme
//templates/yootheme/vendor/yootheme/builder/elements/

//zoo
//plugins/system/yooessentials/modules/core/elements
//plugins/system/yooessentials/modules/form/elements

//morejoomla
//plugins/system/morejoomla_form/elements/

//cloudfood add in child Theme
//templates/yootheme_child1/builder/cf-counter/element.json

//joomlapro
//plugins/system/jp_ce_youtube_channel_grid_joomla/

//flart
//

//forrestkirby
//plugins/system/herzogdupont




class PlgSystemTranslateYooPro extends CMSPlugin
{

    /**
     * Affects constructor behavior. If true, language files will be loaded automatically.
     *
     * @var    boolean
     * @since  1.17 use autoload
     */
    protected $autoloadLanguage = true;

    private static $elements = [];
    private static $elements_pro = [];

    private static $version = "Pro";

    /*
     * @from 1.0
     * @update 1.31 add custom folder (override and custom json)
     * @update 1.33 add dj folder
     * @update 1.38 add hika folder
     * @update 1.44 add moderndesigns folder
     * */
    public function __construct(&$subject, $config)
    {
        parent::__construct($subject, $config);

        $this->loadConfigElements(JPATH_PLUGINS . '/system/translateyoopro/elements/*.json');

        if (self::isLite()) {
            $this->loadProMessageElements(JPATH_PLUGINS . '/system/translateyoopro/elements/pro/*.json');
        } else {

            $this->loadConfigElements(JPATH_PLUGINS . '/system/translateyoopro/elements/cloudfood/*.json');
            $this->loadConfigElements(JPATH_PLUGINS . '/system/translateyoopro/elements/dj/*.json');
            $this->loadConfigElements(JPATH_PLUGINS . '/system/translateyoopro/elements/flart/*.json');
            $this->loadConfigElements(JPATH_PLUGINS . '/system/translateyoopro/elements/joomlapro/*.json');
            $this->loadConfigElements(JPATH_PLUGINS . '/system/translateyoopro/elements/moderndesigns/*.json');
            $this->loadConfigElements(JPATH_PLUGINS . '/system/translateyoopro/elements/morejoomla/*.json');
            $this->loadConfigElements(JPATH_PLUGINS . '/system/translateyoopro/elements/zoo/*.json');
            $this->loadConfigElements(JPATH_PLUGINS . '/system/translateyoopro/elements/forrestkirby/*.json');
            $this->loadConfigElements(JPATH_PLUGINS . '/system/translateyoopro/elements/hika/*.json');

            //add custom folder for custom json and override
            //need to be done at the end
            $this->loadConfigElements(JPATH_PLUGINS . '/system/translateyoopro/custom/*.json');
        }

    }

	public static function isLite(){
	    return strtolower(self::$version) == 'lite';
    }

	private function loadConfigElements($path){
        //load each element supported for translation
        $files = glob($path);

        foreach ($files as $file){
            if(is_file($file)){
                $element = $this->loadJsonFile($file);
                if (isset($element['name'])){
                    static::$elements[$element['name']] = $element;
                }
            }
        }
    }

    /*
     * load pro element to display message on lite version
     *
     * @from 1.18
     * */
    public function loadProMessageElements($path){
        //load each element supported for translation
        $files = glob($path);
        foreach ($files as $file) {
            if (is_file($file)) {
                $element = $this->loadJsonFile($file);
                if (is_array($element)){
                    static::$elements_pro = array_merge(static::$elements_pro,$element);
                }
            }
        }
    }


	public static function getElements(){
	    return static::$elements;
    }

    public static function getProElements(){
        return static::$elements_pro;
    }


    public function onAfterInitialise()
    {
        // Check if YOOtheme Pro is loaded
        if (!class_exists(Application::class, false)) {
            return;
        }

        // Load a single module from the same directory
        $app = Application::getInstance();
        $app->load(__DIR__ . '/bootstrap.php');
    }


    /**
     * Loads a bootstrap config.
     *
     * @param string $file
     * @param array  $parameters
     *
     * @return array
     */
    protected function loadJsonFile($file)
    {
        if (!$content = @file_get_contents($file)) {
            throw new \RuntimeException("Unable to load file '{$file}'");
        }

        if (!is_array($value = @json_decode($content, true))) {
            throw new \RuntimeException("Invalid JSON format in '{$file}'");
        }

        return $value;
    }

    /**
     * don't translate the fulltext article for article made by yootheme
     * use to translate the meta made by Falang
     *
     * @from 1.18 skip fulltext translation display with Falang
     *                 use to allow falang meta translation
     * @since 1.23 fix notice when finder call the method
     * @return boolean false => don't need to display translation by Falang (yootheme content use for search)
     */
    public function onBeforeFieldTranslation($row_to_translate, $row, $language, $reference_table)
    {
        if ($reference_table == 'content' && $row->reference_field == 'fulltext') {
            $default_lang = ComponentHelper::getParams('com_languages')->get('site', 'en-GB');
            if ($default_lang != $language) {
                //finder don't pass introtext and fulltext
                if (!isset($row_to_translate->introtext) ||
                    !isset($row_to_translate->fulltext)
                ) {
                    return true;
                }
                //check it's a yootheme builder ,it's not always in
                if (preg_match('/<!-- Builder/', $row_to_translate->introtext)) {
                    return false;
                }
                //test only the begining
//                if (preg_match('/<!--\s?{/', $row_to_translate->fulltext)){//from wordpress to detect builder
//                    return false;
//                }
                //test the fulltext complety
                ////templates/yootheme/vendor/yootheme/builder-joomla/src/ContentListener.php
                if (preg_match('/^<!-- (\{.*\}) -->/', $row_to_translate->fulltext)) {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * Store the downloadID in the __update_sites table when the plugin is saved
     *
     * @param   string  $context  The context
     * @param   object  $data     The object
     * @param   Form    $form     The form
     *
     * @return  void
     *
     * @since   1.20
     */
    public function onContentNormaliseRequestData($context, $data, Form $form)
    {
        // This plugin only applies to Joomla! 3
        if (version_compare(JVERSION, '3.999.999', 'gt'))
        {
            return;
        }

        if ($context == 'com_plugins.plugin' &&
            isset($data) &&
            isset($data->element) &&
            $data->element == 'translateyoopro')
            {
            // store only valid downloadid
            $download_id = $data->params['fakey'];

            //if (!preg_match('/^([0-9]{1,}:)?[0-9a-f]{32}$/i', $download_id)) return;
            $extra_query = "'dlid=$download_id'";

            $db = Factory::getContainer()->get(DatabaseInterface::class);
            $query = $db->getQuery(true)
                ->select(array('e.extension_id', 'e.type', 'e.name', 'e.manifest_cache', 'us.update_site_id', 'us.enabled', 'us.extra_query'))
                ->from($db->quoteName('#__extensions', 'e'))
                ->join('LEFT OUTER', $db->quoteName('#__update_sites_extensions', 'use') . ' ON (' . $db->quoteName('e.extension_id') . ' = ' .
                    $db->quoteName('use.extension_id') . ')')
                ->join('LEFT OUTER', $db->quoteName('#__update_sites', 'us') . ' ON (' . $db->quoteName('us.update_site_id') . ' = ' .
                    $db->quoteName('use.update_site_id') . ')')
                ->where($db->quoteName('element') . ' = ' . $db->quote('translateyoopro'))
                ->where($db->quoteName('us.update_site_id') . ' IS NOT NULL');


            $db->setQuery($query);
            $component = $db->LoadObject();

            $update_site_id = $component->update_site_id;

            $db = Factory::getContainer()->get(DatabaseInterface::class);
            $query = $db->getQuery(true)
                ->update('#__update_sites')
                ->set('extra_query = '.$extra_query)
                ->where('update_site_id = "'.$update_site_id.'"');
            $db->setQuery($query);
            $db->execute();

        }
        return;
    }

    /**
     * Add Referer SERVER_NAME to the Header
     * downloadID don't have to be managed here
     *
     * @return  boulean
     * @see: https://github.com/akeeba/release-system/wiki/Download-IDs
     *
     * @since   1.20
     */
    public function onInstallerBeforePackageDownload(&$url, &$headers)
    {
        $uri  = Uri::getInstance($url);
        $host = $uri->getHost();

        //update only on faboba.com
        if ( strpos($host, 'faboba.com') === false )
        {
            return;
        }

        $headers['Referer'] = isset($_SERVER['SERVER_NAME'])?$_SERVER['SERVER_NAME']:'unknown';

    }

}


