<?php

use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Language\LanguageHelper;
use Joomla\CMS\Factory;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\Database\DatabaseInterface;
use YOOtheme\Builder;
use YOOtheme\Http\Request;
use YOOtheme\Http\Response;
use function YOOtheme\app;

class PageListener
{

    /**
     * During the save page action
     *
     * from : templates/yootheme/packages/builder-joomla/src/PageController.php
     * savePage
     *
     * @from 1.27
     *
     * @param Request $request
     * @param callable $next
     *
     * @return Response
     */
    public static function handle($request, callable $next)
    {
        //only for savePage
        if ($request->getParam('p') !== 'page' || $request->getMethod() !== 'POST') {
            return $next($request);
        }

        $request
            ->abortIf(!($page = $request->getParam('page')), 400)
            ->abortIf(!($page = base64_decode($page)), 400)
            ->abortIf(!($page = json_decode($page)), 400);

        if ((array)$page->content) {
            $content = json_encode($page->content);
            $builder = app(Builder::class);
            $builder->addTransform('precontent', new YooTranslateTransform());
            $languages = LanguageHelper::getLanguages('lang_code');
            $default_lang = ComponentHelper::getParams('com_languages')->get('site', 'en-GB');
            foreach ($languages as $language) {
                //TODO default langauge save the render in the original article
                if ($default_lang == $language->lang_code){continue;}
                try {
                    //be sure to not exception or the save is stopped
                    $introtext = $builder->withParams(['context' => 'content', 'search' => 'true', 'lang' => $language->lang_code])->render($content);
                    self::saveTextforSmartSearch($page,$introtext,$language);
                }
                catch (\Exception $e)
                {
                //nothing to do need to contineu the save process
                }
            }
        }

        return $next($request);
    }

    /*
     * Save render text in falang translation only if exist
     * Falang plugin need to be enabled
     * Falang translation need to exist for this language (not stored)
     * Falang version need to be
     *
     * @update 1.40 md5(null) deprecated need an empty string
     * */
    private static function saveTextforSmartSearch($page,$text,$language)
    {
        //falalngdriver system plugins need to be published.
        $falang_plugin = PluginHelper::getPlugin('system', 'falangdriver');
        if (empty($falang_plugin)){return true;}


        $db = Factory::getContainer()->get(DatabaseInterface::class);
        $query = $db->getQuery(true);
        $query->select($query->qn('id'))
            ->from($query->qn('#__falang_content'))
            ->where($db->qn('language_id') . ' = ' . $db->q($language->lang_id))
            ->where($db->qn('reference_id') . ' = ' . $page->id)
            ->where($db->qn('reference_field') . ' = ' . $db->q('introtext'))
            ->where($db->qn('reference_table') . ' = ' . $db->q('content'));

        $db->setQuery($query);
        $falangId = $db->loadResult();

        //since Falang 5.18 FalangContent is now in src/Table FalangContentTable and namespace used
        if (is_file(FALANG_ADMINPATH.'/src/Table/FalangContentTable.php')){
            require_once(FALANG_ADMINPATH.'/src/Table/FalangContentTable.php');
            $fieldContent = new Falang\Component\Administrator\Table\FalangContentTable($db);

            if (isset($falangId)) {
                $fieldContent->id = $falangId;
                $fieldContent->reference_id = $page->id;
                $fieldContent->language_id = $language->lang_id;
                $fieldContent->reference_table = 'content';
                $fieldContent->reference_field = 'introtext';
                $fieldContent->value = $text;
                $fieldContent->original_value = md5("");

                $fieldContent->modified = Factory::getDate()->toSql();
                $user = Factory::getApplication()->getIdentity();
                $fieldContent->modified_by = $user->id;
                $fieldContent->published = true;

                $fieldContent->store();
            }

        }
    }

}