<?php
/**
 * @package     Yootheme Pro Translate for Joomla!
 * @author      Stéphane Bouey <stephane.bouey@faboba.com> - http://www.faboba.com
 * @license     GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 * @copyright   Copyright (C) 2012-2022 Faboba. All rights reserved.
 */

// No direct access to this file
defined('_JEXEC') or die();

use Joomla\CMS\Factory;
use Joomla\Database\DatabaseInterface;
use YOOtheme\Config;
use Joomla\CMS\Language\Text;

class FalangSettingsListener
{
    /*
     * Add Faboba panel to display the version
     * Add Cookiet translation
     *
     * @since 1.14 subtitle translation (new in Yootheme builder 3.0)
     * @since 1.21 add logo text, image, breadcrumbs homes translation
     * @since 1.41 add DJ Poppup
     * @since 2.1 Cookie translation only for Yootheme 4
     * */
    public static function initCustomizer(Config $config)
    {
        // Add panel using a dynamic PHP configuration
        $config->set('customizer.panels.translateyoopro', [
            'title'  => 'Translate for Yootheme',
            'width'  => 400,
            'fields' => [
                'version' => [
                    'type' => 'none',
                    'description'=> 'Version : '. FalangSettingsListener::getPluginVersion(),
                ]
            ]
        ]);

        $config->set('customizer.sections.settings.fields.settings.items.translateyoopro', 'Faboba');

        //add Cookie Panel for Yootheme 5
        $yoo_version = $config->get('theme')['version'];
        if (version_compare($yoo_version, '4.0', '>=') && version_compare($yoo_version, '5.0', '<')) {
            // Code compat 4.x et 5.x
            FalangSettingsListener::addCookieTranslation($config);
        }
        //Cookie Panel for Yootheme 5 is Consent Manager but no way to translate it
        if (version_compare($yoo_version, '5.0', '>=') && version_compare($yoo_version, '6.0', '<')) {
            //FalangSettingsListener::addCookieTranslation($config);
        }


        //add Site Panel
        FalangSettingsListener::addSiteTranslation($config);

        //add Menu Title
        FalangSettingsListener::addMenuTranslation($config);

        //add Yooessential Valide message not yet working
        //FalangSettingsListener::addYOOEssentialTranslation($config);

        //add Ruhe
        FalangSettingsListener::addRuheTranslation($config);

        //add DJ-Popup
        FalangSettingsListener::addDJPopupTranslation($config);
    }

    /*
     * get Translate YooProo plugin version
     * */
    public static function getPluginVersion(){
        $db = Factory::getContainer()->get(DatabaseInterface::class);
        $query = $db->getQuery(true);
        $query->select('manifest_cache');
        $query->from($db->quoteName('#__extensions'));
        $query->where('folder = "system"');
        $query->where('type = "plugin"');
        $query->where('element = "translateyoopro"');
        $db->setQuery($query);

        $manifest = json_decode($db->loadResult(), true);
        if (isset( $manifest['version'])){
            return $manifest['version'];
        } else {
            return 'unknown';
        }
    }

    /*
     * Add cookie panel translation
     * @from 1.31
     * @update 1.42 use getTranslatedPanelTab tab without space
     * */
    public static function addCookieTranslation(Config $config){

        //translate cookie information
        $translated_fields = ['cookie.message','cookie.button_consent_text','cookie.button_reject_text'];

        $fields = $config->get('customizer.panels.cookie.fields');

        $languages = YooTranslateTransform::getLanguages(false);

        //add Falang field
        $falang_field = [
            "label" => "Falang",
            "type" => "group",
        ];

        $config->add('customizer.panels.cookie.fields',['_falang' => $falang_field]);

        //add panel for each language on cookie banner
        foreach ($languages as $language){
            $language_panel_cookie_name = YooTranslateTransform::getTranslatedPanelTab("language-panel-cookie",$language);
            //add a button panel by language
            $panel_cookie = [
                "text" => sprintf(Text::_('PLG_TRANSLATEYOOPRO_TRANSLATE_BTN'), $language->title),
                "type" => "button-panel",
                'panel' => $language_panel_cookie_name
            ];

            $config->add('customizer.panels.cookie.fields',['_'.$language_panel_cookie_name => $panel_cookie]);
            $description_cookie_language =  sprintf(
                Text::_( 'PLG_TRANSLATEYOOPRO_PANEL_COOKIE_DESCRIPTION'),
                $language->title
            );
            //create the panel for the cookie language
            $language_panel_cookie = [
                "title" =>  sprintf(Text::_('PLG_TRANSLATEYOOPRO_PANEL_NAME'), $language->title),//no title to keep cookie banner
                "width" => 400,
                "fields" => ['_language_panel_cookie' =>
                    [
                        "description" => $description_cookie_language,
                        "type" => "description"
                    ]
                ]
            ];

            foreach ($translated_fields as $translated_field){
                $new_field = $fields[$translated_field];
                $new_field['label'] =YooTranslateTransform::getTranslatedFieldLabel($fields[$translated_field]['label'],$language);
                $transated_field_name = YooTranslateTransform::getTranslatedFieldName($translated_field,$language);
                $language_panel_cookie['fields'][$transated_field_name] = $new_field;
            }

            $config->add('customizer.panels',[$language_panel_cookie_name =>  $language_panel_cookie ]);

        }
    }

    /*
     * Add site panel translation
     * @from 1.31
     * @update 1.42 use getTranslatedPanelTab tab without space
     * */
    public static function addSiteTranslation(Config $config){

        //translate site information
        $translated_site_fields = ['logo.text','logo.image','site.breadcrumbs_home_text'];

        $fields = $config->get('customizer.panels.site.fields');

        $languages = YooTranslateTransform::getLanguages(false);

        //add Falang field
        $falang_field = [
            "label" => "Falang",
            "type" => "group",
        ];

        $config->add('customizer.panels.site.fields',['_falang' => $falang_field]);

        //add panel for each language on cookie banner
        foreach ($languages as $language){
            $language_panel_site_name = YooTranslateTransform::getTranslatedPanelTab("language-panel-site",$language);
            //add a button panel by language
            $panel_site = [
                "text" => sprintf(Text::_('PLG_TRANSLATEYOOPRO_TRANSLATE_BTN'), $language->title),
                "type" => "button-panel",
                'panel' => $language_panel_site_name
            ];

            $config->add('customizer.panels.site.fields',['_'.$language_panel_site_name => $panel_site]);
            $description_site_language =  sprintf(
                Text::_( 'PLG_TRANSLATEYOOPRO_PANEL_SITE_DESCRIPTION'),
                $language->title
            );
            //create the panel for the site language
            $language_panel_site = [
                "title" =>  sprintf(Text::_('PLG_TRANSLATEYOOPRO_PANEL_NAME'), $language->title),//no title on Joomla
                "width" => 400,
                "fields" => ['_language_panel_cookie' =>
                    [
                        "description" => $description_site_language,
                        "type" => "description"
                    ]
                ]
            ];

            foreach ($translated_site_fields as $translated_field){
                $new_field = $fields[$translated_field];
                $new_field['label'] =YooTranslateTransform::getTranslatedFieldLabel($fields[$translated_field]['label'],$language);
                $transated_field_name = YooTranslateTransform::getTranslatedFieldName($translated_field,$language);
                $language_panel_site['fields'][$transated_field_name] = $new_field;
            }

            $config->add('customizer.panels',[$language_panel_site_name =>  $language_panel_site ]);

        }
    }

    /*
     * Add Menu panel translation for Sub Menu
     * @from 1.31
     * */
    public static function addMenuTranslation(Config $config){
        $languages = YooTranslateTransform::getLanguages(false);

        $translated_mfields = ['subtitle'];
        $mfields = $config->get('customizer.panels.menu-item.fields');
        foreach ($languages as $language){
            foreach ($translated_mfields as $translated_field){
                if (isset($mfields[$translated_field])) {
                    $new_field = $mfields[$translated_field];
                    $new_field['label'] = YooTranslateTransform::getTranslatedFieldLabel($mfields[$translated_field]['label'], $language);
                    $transated_field_name = YooTranslateTransform::getTranslatedFieldName($translated_field, $language);

                    $config->add('customizer.panels.menu-item.fields', [$transated_field_name => $new_field]);
                }
            }
        }

    }

    /*
     * Add Menu panel translation for Sub Menu
     * Not yet working
     * @from 1.43
     * */
    public static function addYOOEssentialTranslation(Config $config){
        $languages = YooTranslateTransform::getLanguages(false);

        $translated_mfields = ['message'];
        //$mfields = $config->get('customizer.panels.menu-item.fields');
        $mfields = $config->get('yooessentials.customizer.form_actions.validate.fields');

        foreach ($languages as $language){
            foreach ($translated_mfields as $translated_field){
                if (isset($mfields[$translated_field])) {
                    $new_field = $mfields[$translated_field];
                    $new_field['label'] = YooTranslateTransform::getTranslatedFieldLabel($mfields[$translated_field]['label'], $language);
                    $transated_field_name = YooTranslateTransform::getTranslatedFieldName($translated_field, $language);

                    $config->add('yooessentials.customizer.form_actions.validate.fields', [$transated_field_name => $new_field]);
                }
            }
        }
    }

    /*
    * Add RuhePotenetial extra panel
    * priority -10 in bootstrap to allow working whith every plugin order (falang/ruhe)
    * @from 1.37
    */
    public static function addRuheTranslation(Config $config)
    {
        FalangSettingsListener::addRuheGoogleAnalytics($config);
        FalangSettingsListener::addRuheGoogleMaps($config);
        FalangSettingsListener::addRuheGoogleTagManager($config);
        FalangSettingsListener::addRuheOpenstreetMap($config);
        FalangSettingsListener::addRuheRecaptcha($config);
        FalangSettingsListener::addRuheVimeo($config);
        FalangSettingsListener::addRuheYoutube($config);

        FalangSettingsListener::addRuheSDPOverlay($config);//Smart data protector Overlay
        FalangSettingsListener::addRuheSDPText($config);//Smart data protector Text
        FalangSettingsListener::addRuheSDPMessage($config);//Smart data protector Message

    }


    /*
    * Add RuhePotenetial Google Analytics
    * @from 1.37
     *
     * @update 2.0 remove warning if no language configured
    */
    public static function addRuheGoogleAnalytics(Config $config){
        $languages = YooTranslateTransform::getLanguages(false);

        if (empty($languages)){return;}

        $keyname = 'corporate.consent.google_analytics.';

        $translated_mfields = ['title','content','link','button_info','button_consent','button_reject','button_withdrawal'];//,'button_info','button_consent','button_reject'
        $mfields = $config->get('customizer.panels.corporate-consent-google-analytics.fields');
        $newFieldListName = [];
        foreach ($languages as $language) {
            foreach ($translated_mfields as $translated_field) {
                if (isset($mfields[$keyname.$translated_field])) {
                    $new_field = $mfields[$keyname.$translated_field];
                    $new_field['label'] = YooTranslateTransform::getTranslatedFieldLabel($mfields[$keyname.$translated_field]['label'], $language);
                    $transated_field_name = YooTranslateTransform::getTranslatedFieldName($translated_field, $language);

                    $config->add('customizer.panels.corporate-consent-google-analytics.fields', [$keyname.$transated_field_name => $new_field]);
                    $newFieldListName[] = $keyname.$transated_field_name;

                }
            }
        }
        //add new translated field to the Falang tab
        $tabs_google = [
            "title" =>  sprintf(Text::_('PLG_TRANSLATEYOOPRO_TAB_NAME'), $language->title),//no title on Joomla
            'fields' => $newFieldListName
        ];

        //get the number of fields to add it in the last posittion in case of chagne
        if (!empty($config->get('customizer.panels.corporate-consent-google-analytics.fieldset.default.fields'))){
            $last_idx = count($config->get('customizer.panels.corporate-consent-google-analytics.fieldset.default.fields'));
            $config->add('customizer.panels.corporate-consent-google-analytics.fieldset.default.fields',[$last_idx => $tabs_google]);
        }

    }

    /*
    * Add RuhePotenetial Google Maps
    * @from 1.37
    */
    public static function addRuheGoogleMaps(Config $config){
        $languages = YooTranslateTransform::getLanguages(false);

        if (empty($languages)){return;}

        $keyname = 'corporate.consent.google_maps.';

        $translated_mfields = ['title','content','image','image_alt','link','button_info','button_consent','button_withdrawal'];
        $mfields = $config->get('customizer.panels.corporate-consent-google-maps.fields');
        $newFieldListName = [];
        foreach ($languages as $language) {
            foreach ($translated_mfields as $translated_field) {
                if (isset($mfields[$keyname.$translated_field])) {
                    $new_field = $mfields[$keyname.$translated_field];
                    $new_field['label'] = YooTranslateTransform::getTranslatedFieldLabel($mfields[$keyname.$translated_field]['label'], $language);
                    $transated_field_name = YooTranslateTransform::getTranslatedFieldName($translated_field, $language);

                    $config->add('customizer.panels.corporate-consent-google-maps.fields', [$keyname.$transated_field_name => $new_field]);
                    $newFieldListName[] = $keyname.$transated_field_name;

                }
            }
        }
        //add new translated field to the Falang tab
        $tabs_google = [
            "title" =>  sprintf(Text::_('PLG_TRANSLATEYOOPRO_TAB_NAME'), $language->title),//no title on Joomla
            'fields' => $newFieldListName
        ];

        //get the number of fields to add it in the last posittion in case of chagne
        if (!empty($config->get('customizer.panels.corporate-consent-google-maps.fieldset.default.fields'))){
            $last_idx = count($config->get('customizer.panels.corporate-consent-google-maps.fieldset.default.fields'));
            $config->add('customizer.panels.corporate-consent-google-maps.fieldset.default.fields',[$last_idx => $tabs_google]);
        }

    }

    /*
    * Add RuhePotenetial Google Tag Manager
    * @from 1.37
    */
    public static function addRuheGoogleTagManager(Config $config){
        $languages = YooTranslateTransform::getLanguages(false);

        if (empty($languages)){return;}

        $keyname = 'corporate.consent.google_tag_manager.';

        $translated_mfields = ['title','content','link','button_info','button_consent','button_reject','button_withdrawal'];
        $mfields = $config->get('customizer.panels.corporate-consent-google-tag-manager.fields');
        $newFieldListName = [];
        foreach ($languages as $language) {
            foreach ($translated_mfields as $translated_field) {
                if (isset($mfields[$keyname.$translated_field])) {
                    $new_field = $mfields[$keyname.$translated_field];
                    $new_field['label'] = YooTranslateTransform::getTranslatedFieldLabel($mfields[$keyname.$translated_field]['label'], $language);
                    $transated_field_name = YooTranslateTransform::getTranslatedFieldName($translated_field, $language);

                    $config->add('customizer.panels.corporate-consent-google-tag-manager.fields', [$keyname.$transated_field_name => $new_field]);
                    $newFieldListName[] = $keyname.$transated_field_name;

                }
            }
        }
        //add new translated field to the Falang tab
        $tabs_google = [
            "title" =>  sprintf(Text::_('PLG_TRANSLATEYOOPRO_TAB_NAME'), $language->title),//no title on Joomla
            'fields' => $newFieldListName
        ];

        //get the number of fields to add it in the last posittion in case of chagne
        if (!empty($config->get('customizer.panels.corporate-consent-google-tag-manager.fieldset.default.fields'))){
            $last_idx = count($config->get('customizer.panels.corporate-consent-google-tag-manager.fieldset.default.fields'));
            $config->add('customizer.panels.corporate-consent-google-tag-manager.fieldset.default.fields',[$last_idx => $tabs_google]);
        }

    }

    /*
    * Add RuhePotenetial OpenStreetMap
    * @from 1.37
    */
    public static function addRuheOpenstreetMap(Config $config){
        $languages = YooTranslateTransform::getLanguages(false);

        if (empty($languages)){return;}

        $keyname = 'corporate.consent.openstreetmap.';

        $translated_mfields = ['title','content','image','image_alt','link','button_info','button_consent','button_withdrawal'];
        $mfields = $config->get('customizer.panels.corporate-consent-openstreetmap.fields');
        $newFieldListName = [];
        foreach ($languages as $language) {
            foreach ($translated_mfields as $translated_field) {
                if (isset($mfields[$keyname.$translated_field])) {
                    $new_field = $mfields[$keyname.$translated_field];
                    $new_field['label'] = YooTranslateTransform::getTranslatedFieldLabel($mfields[$keyname.$translated_field]['label'], $language);
                    $transated_field_name = YooTranslateTransform::getTranslatedFieldName($translated_field, $language);

                    $config->add('customizer.panels.corporate-consent-openstreetmap.fields', [$keyname.$transated_field_name => $new_field]);
                    $newFieldListName[] = $keyname.$transated_field_name;

                }
            }
        }
        //add new translated field to the Falang tab
        $tabs_google = [
            "title" =>  sprintf(Text::_('PLG_TRANSLATEYOOPRO_TAB_NAME'), $language->title),//no title on Joomla
            'fields' => $newFieldListName
        ];

        //get the number of fields to add it in the last posittion in case of chagne
        if (!empty($config->get('customizer.panels.corporate-consent-openstreetmap.fieldset.default.fields'))){
            $last_idx = count($config->get('customizer.panels.corporate-consent-openstreetmap.fieldset.default.fields'));
            $config->add('customizer.panels.corporate-consent-openstreetmap.fieldset.default.fields',[$last_idx => $tabs_google]);
        }

    }

    /*
    * Add RuhePotenetial Recaptcha
    * @from 1.37
    */
    public static function addRuheRecaptcha(Config $config){
        $languages = YooTranslateTransform::getLanguages(false);

        if (empty($languages)){return;}

        $keyname = 'corporate.consent.recaptcha.';

        $translated_mfields = ['content','link','button_withdrawal'];
        $mfields = $config->get('customizer.panels.corporate-consent-recaptcha.fields');
        $newFieldListName = [];
        foreach ($languages as $language) {
            foreach ($translated_mfields as $translated_field) {
                if (isset($mfields[$keyname.$translated_field])) {
                    $new_field = $mfields[$keyname.$translated_field];
                    $new_field['label'] = YooTranslateTransform::getTranslatedFieldLabel($mfields[$keyname.$translated_field]['label'], $language);
                    $transated_field_name = YooTranslateTransform::getTranslatedFieldName($translated_field, $language);

                    $config->add('customizer.panels.corporate-consent-recaptcha.fields', [$keyname.$transated_field_name => $new_field]);
                    $newFieldListName[] = $keyname.$transated_field_name;

                }
            }
        }
        //add new translated field to the Falang tab
        $tabs_google = [
            "title" =>  sprintf(Text::_('PLG_TRANSLATEYOOPRO_TAB_NAME'), $language->title),//no title on Joomla
            'fields' => $newFieldListName
        ];

        //get the number of fields to add it in the last posittion in case of chagne
        if (!empty($config->get('customizer.panels.corporate-consent-recaptcha.fieldset.default.fields'))){
            $last_idx = count($config->get('customizer.panels.corporate-consent-recaptcha.fieldset.default.fields'));
            $config->add('customizer.panels.corporate-consent-recaptcha.fieldset.default.fields',[$last_idx => $tabs_google]);
        }


    }

    /*
    * Add RuhePotenetial Vimeo
    * @from 1.37
    */
    public static function addRuheVimeo(Config $config){
        $languages = YooTranslateTransform::getLanguages(false);

        if (empty($languages)){return;}

        $keyname = 'corporate.consent.vimeo.';

        $translated_mfields = ['title','content','image','image_alt','link','button_info','button_consent','button_withdrawal'];
        $mfields = $config->get('customizer.panels.corporate-consent-vimeo.fields');
        $newFieldListName = [];
        foreach ($languages as $language) {
            foreach ($translated_mfields as $translated_field) {
                if (isset($mfields[$keyname.$translated_field])) {
                    $new_field = $mfields[$keyname.$translated_field];
                    $new_field['label'] = YooTranslateTransform::getTranslatedFieldLabel($mfields[$keyname.$translated_field]['label'], $language);
                    $transated_field_name = YooTranslateTransform::getTranslatedFieldName($translated_field, $language);

                    $config->add('customizer.panels.corporate-consent-vimeo.fields', [$keyname.$transated_field_name => $new_field]);
                    $newFieldListName[] = $keyname.$transated_field_name;

                }
            }
        }
        //add new translated field to the Falang tab
        $tabs_google = [
            "title" =>  sprintf(Text::_('PLG_TRANSLATEYOOPRO_TAB_NAME'), $language->title),//no title on Joomla
            'fields' => $newFieldListName
        ];

        //get the number of fields to add it in the last posittion in case of chagne
        if (!empty($config->get('customizer.panels.corporate-consent-vimeo.fieldset.default.fields'))){
            $last_idx = count($config->get('customizer.panels.corporate-consent-vimeo.fieldset.default.fields'));
            $config->add('customizer.panels.corporate-consent-vimeo.fieldset.default.fields',[$last_idx => $tabs_google]);
        }

    }

    /*
    * Add RuhePotenetial Youtube
    * @from 1.37
    */
    public static function addRuheYoutube(Config $config){
        $languages = YooTranslateTransform::getLanguages(false);

        if (empty($languages)){return;}

        $keyname = 'corporate.consent.youtube.';

        $translated_mfields = ['title','content','image','image_alt','link','button_info','button_consent','button_withdrawal'];
        $mfields = $config->get('customizer.panels.corporate-consent-youtube.fields');
        $newFieldListName = [];
        foreach ($languages as $language) {
            foreach ($translated_mfields as $translated_field) {
                if (isset($mfields[$keyname.$translated_field])) {
                    $new_field = $mfields[$keyname.$translated_field];
                    $new_field['label'] = YooTranslateTransform::getTranslatedFieldLabel($mfields[$keyname.$translated_field]['label'], $language);
                    $transated_field_name = YooTranslateTransform::getTranslatedFieldName($translated_field, $language);

                    $config->add('customizer.panels.corporate-consent-youtube.fields', [$keyname.$transated_field_name => $new_field]);
                    $newFieldListName[] = $keyname.$transated_field_name;

                }
            }
        }
        //add new translated field to the Falang tab
        $tabs_google = [
            "title" =>  sprintf(Text::_('PLG_TRANSLATEYOOPRO_TAB_NAME'), $language->title),//no title on Joomla
            'fields' => $newFieldListName
        ];

        //get the number of fields to add it in the last posittion in case of chagne
        if (!empty($config->get('customizer.panels.corporate-consent-youtube.fieldset.default.fields'))){
            $last_idx = count($config->get('customizer.panels.corporate-consent-youtube.fieldset.default.fields'));
            $config->add('customizer.panels.corporate-consent-youtube.fieldset.default.fields',[$last_idx => $tabs_google]);
        }

    }

    /*
    * Add RuhePotenetial Smart Data Protector Overlay
    * @from 1.37
    */
    public static function addRuheSDPOverlay(Config $config)
    {
        $languages = YooTranslateTransform::getLanguages(false);

        if (empty($languages)){return;}

        $keyname = 'corporate.usercentrics.sdp.';

        $translated_mfields = ['title','content','content_map','content_video','button_info','button_consent'];
        $mfields = $config->get('customizer.panels.corporate-usercentrics-sdp-overlay.fields');
        $newFieldListName = [];
        foreach ($languages as $language) {
            foreach ($translated_mfields as $translated_field) {
                if (isset($mfields[$keyname.$translated_field])) {
                    $new_field = $mfields[$keyname.$translated_field];
                    $new_field['label'] = YooTranslateTransform::getTranslatedFieldLabel($mfields[$keyname.$translated_field]['label'], $language);
                    $transated_field_name = YooTranslateTransform::getTranslatedFieldName($translated_field, $language);

                    $config->add('customizer.panels.corporate-usercentrics-sdp-overlay.fields', [$keyname.$transated_field_name => $new_field]);
                    $newFieldListName[] = $keyname.$transated_field_name;

                }
            }
        }
        //add new translated field to the Falang tab
        $tabs_google = [
            "title" =>  sprintf(Text::_('PLG_TRANSLATEYOOPRO_TAB_NAME'), $language->title),//no title on Joomla
            'fields' => $newFieldListName
        ];

        //get the number of fields to add it in the last posittion in case of chagne
        if (!empty($config->get('customizer.panels.corporate-usercentrics-sdp-overlay.fieldset.default.fields'))){
            $last_idx = count($config->get('customizer.panels.corporate-usercentrics-sdp-overlay.fieldset.default.fields'));
            $config->add('customizer.panels.corporate-usercentrics-sdp-overlay.fieldset.default.fields',[$last_idx => $tabs_google]);
        }
    }

    /*
    * Add RuhePotenetial Smart Data Protector Overlay
    * @from 1.37
    */
    public static function addRuheSDPText(Config $config)
    {
        $languages = YooTranslateTransform::getLanguages(false);

        if (empty($languages)){return;}

        $keyname = 'corporate.usercentrics.sdp.';

        $translated_mfields = ['content_recaptcha'];
        $mfields = $config->get('customizer.panels.corporate-usercentrics-sdp-text.fields');
        $newFieldListName = [];
        foreach ($languages as $language) {
            foreach ($translated_mfields as $translated_field) {
                if (isset($mfields[$keyname.$translated_field])) {
                    $new_field = $mfields[$keyname.$translated_field];
                    $new_field['label'] = YooTranslateTransform::getTranslatedFieldLabel($mfields[$keyname.$translated_field]['label'], $language);
                    $transated_field_name = YooTranslateTransform::getTranslatedFieldName($translated_field, $language);

                    $config->add('customizer.panels.corporate-usercentrics-sdp-text.fields', [$keyname.$transated_field_name => $new_field]);
                    $newFieldListName[] = $keyname.$transated_field_name;

                }
            }
        }
        //add new translated field to the Falang tab
        $tabs_google = [
            "title" =>  sprintf(Text::_('PLG_TRANSLATEYOOPRO_TAB_NAME'), $language->title),//no title on Joomla
            'fields' => $newFieldListName
        ];

        //get the number of fields to add it in the last posittion in case of chagne
        if (!empty($config->get('customizer.panels.corporate-usercentrics-sdp-text.fieldset.default.fields'))){
            $last_idx = count($config->get('customizer.panels.corporate-usercentrics-sdp-text.fieldset.default.fields'));
            $config->add('customizer.panels.corporate-usercentrics-sdp-text.fieldset.default.fields',[$last_idx => $tabs_google]);
        }
    }

    /*
    * Add RuhePotenetial Smart Data Protector Message
    * @from 1.37
    */
    public static function addRuheSDPMessage(Config $config)
    {
        $languages = YooTranslateTransform::getLanguages(false);

        if (empty($languages)){return;}

        $keyname = 'corporate.usercentrics.sdp.';

        $translated_mfields = ['permission'];
        $mfields = $config->get('customizer.panels.corporate-usercentrics-sdp-message.fields');
        $newFieldListName = [];
        foreach ($languages as $language) {
            foreach ($translated_mfields as $translated_field) {
                if (isset($mfields[$keyname.$translated_field])) {
                    $new_field = $mfields[$keyname.$translated_field];
                    $new_field['label'] = YooTranslateTransform::getTranslatedFieldLabel($mfields[$keyname.$translated_field]['label'], $language);
                    $transated_field_name = YooTranslateTransform::getTranslatedFieldName($translated_field, $language);

                    $config->add('customizer.panels.corporate-usercentrics-sdp-message.fields', [$keyname.$transated_field_name => $new_field]);
                    $newFieldListName[] = $keyname.$transated_field_name;

                }
            }
        }
        //add new translated field to the Falang tab
        $tabs_google = [
            "title" =>  sprintf(Text::_('PLG_TRANSLATEYOOPRO_TAB_NAME'), $language->title),//no title on Joomla
            'fields' => $newFieldListName
        ];

        //get the number of fields to add it in the last posittion in case of chagne
        if (!empty($config->get('customizer.panels.corporate-usercentrics-sdp-message.fieldset.default.fields'))){
            $last_idx = count($config->get('customizer.panels.corporate-usercentrics-sdp-message.fieldset.default.fields'));
            $config->add('customizer.panels.corporate-usercentrics-sdp-message.fieldset.default.fields',[$last_idx => $tabs_google]);
        }
    }

    /*
       * Add DJ Popup translation
       * @from 1.41
       * */
    public static function addDJPopupTranslation(Config $config){
        $languages = YooTranslateTransform::getLanguages(false);

        if (empty($languages)){return;}

        $translated_mfields = ['djpopup.heading','djpopup.save_text','djpopup.save_link','djpopup.cancel_text'];
        $mfields = $config->get('customizer.panels.djpopup-form-config.fields');
        $newFieldListName = [];
        foreach ($languages as $language){
            foreach ($translated_mfields as $translated_field){
                if (isset($mfields[$translated_field])) {
                    $new_field = $mfields[$translated_field];
                    if (isset($fields[$translated_field]) && $fields[$translated_field]['label']){
                        $transated_field_label = str_replace('Djpopup.','',YooTranslateTransform::getTranslatedFieldLabel($fields[$translated_field]['label'],$language));//remove Djpopup. from the label keep Heading FR_FR
                        $new_field['label'] = $transated_field_label;
                    } else {
                        $transated_field_label = str_replace('Djpopup.','',YooTranslateTransform::getTranslatedFieldLabel($translated_field,$language));//remove djpopup. from the label keep Heading FR_FR
                        $new_field['label'] = $transated_field_label;
                    }
                    $transated_field_name = YooTranslateTransform::getTranslatedFieldName($translated_field,$language);
                    $config->add('customizer.panels.djpopup-form-config.fields', [$transated_field_name => $new_field]);

                    $newFieldListName[] = $transated_field_name;

                }
            }
        }

        //add new translated field to the Falang tab
        $tabs_djpopup = [
            "title" =>  sprintf(Text::_('PLG_TRANSLATEYOOPRO_TAB_NAME'), $language->title),//no title on Joomla
            'fields' => $newFieldListName
        ];

        //get the number of fields to add it in the last posittion in case of change
        if (!empty($config->get('customizer.panels.djpopup-form-config.fieldset.default.fields'))){
            $last_idx = count($config->get('customizer.panels.djpopup-form-config.fieldset.default.fields'));
            $config->add('customizer.panels.djpopup-form-config.fieldset.default.fields',[$last_idx => $tabs_djpopup]);
        }


    }
}
