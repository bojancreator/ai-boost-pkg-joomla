<?php

use YOOtheme\Builder;
use YOOtheme\Config;
use YOOtheme\Path;
use YOOtheme\View;
use YOOtheme\Builder\UpdateTransform;
use YOOtheme\Builder\ElementTransform;

include_once __DIR__ . '/src/SettingsListener.php';
include_once __DIR__ . '/src/PageListener.php';
include_once __DIR__ . '/yootranslatetransform.php';

return [


    // Add builder elements
    'extend' => [

        Builder::class => function (Builder $builder) {
            //$builder->addTypePath(Path::get('./elements/*/element.json'));
            $builder->addTransform('prerender', new yootranslatetransform());
        }

    ],
    'events' => [

        'theme.init' => [
            YooTranslateTransform::class => 'initTheme',
        ],

        'builder.type' => [
            YooTranslateTransform::class => ['initSource', 50],
        ],

        // Add settings Panels
        'customizer.init' => [
            FalangSettingsListener::class => ['initCustomizer',-10]
        ],

        //save the translated content for search (only with Falang )
        'app.request' => [
            PageListener::class => ['@handle', 10],
        ]
    ],

];
