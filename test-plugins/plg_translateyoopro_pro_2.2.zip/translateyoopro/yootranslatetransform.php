<?php
/**
 * @package     Yootheme Pro Translate for Joomla!
 * @author      Stéphane Bouey <stephane.bouey@faboba.com> - http://www.faboba.com
 * @license     GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 * @copyright   Copyright (C) 2012-2025 Faboba. All rights reserved.
 */

use Joomla\CMS\Factory;
use Joomla\CMS\Component\ComponentHelper;
use Joomla\CMS\Language\LanguageHelper;
use Joomla\CMS\Language\Text;
use YOOtheme\Config;

class YooTranslateTransform
{

    /**
     * init Thme
     * Use for Front-end translation of cookie message
     *
     * @since 1.14 menu subtitle translation
     * @since 1.21 add logo_text , logo_image, breadcrumbs home text translation
     * @since 1.37 add RuhePotential support
     */
    public static function initTheme(Config $config)
    {
        $input = Factory::getApplication()->input;
        $customizer = $input->get('customizer',null);
        //don't translate on admin or during the customizer
        if ($config('app.isSite') && !isset($customizer)) {

            $languages = LanguageHelper::getLanguages('lang_code');
            $currentLanguage = $languages[Factory::getLanguage()->getTag()];
            $default_lang = ComponentHelper::getParams('com_languages')->get('site', 'en-GB');

            if ($currentLanguage->lang_code == $default_lang ){
                return;
            }

            $translated_fields = ['cookie.message','cookie.button_consent_text','cookie.button_reject_text',
                'logo.text','logo.image','site.breadcrumbs_home_text'
            ];

            //replace the field original with the translation if exist
            foreach ($translated_fields as $translated_field){
                $translated_field_name =  YooTranslateTransform::getTranslatedFieldName($translated_field,$currentLanguage);
                $translation =  $config('~theme.'.$translated_field_name);
                if (isset($translation) && !empty($translation)){
                    $config->set('~theme.'.$translated_field , $translation);
                }
            }

            //menu subtitle
            $translated_mfields = ['subtitle'];
            foreach ($translated_mfields as $translated_field){
                $translated_field_name =  YooTranslateTransform::getTranslatedFieldName($translated_field,$currentLanguage);
                $menu_items = $config('~theme.menu.items');
                foreach ($menu_items as $idx => $menu_item){
                    if (isset($menu_item[$translated_field_name])){
                        $translation =  $menu_item[$translated_field_name];
                        if (isset($translation)){
                            $config->set('~theme.menu.items.'.$idx.'.'.$translated_field , $translation);
                        }
                    }
                }
            }
            //ruhe potential defined in Settings Listener
            $translated_fields = [
                //Google Analytics
                'corporate.consent.google_analytics.title',
                'corporate.consent.google_analytics.content',
                'corporate.consent.google_analytics.link',
                'corporate.consent.google_analytics.button_info',
                'corporate.consent.google_analytics.button_consent',
                'corporate.consent.google_analytics.button_reject',
                'corporate.consent.google_analytics.button_withdrawal',
                //gooogle map
                'corporate.consent.google_maps.title',
                'corporate.consent.google_maps.content',
                'corporate.consent.google_maps.image',
                'corporate.consent.google_maps.image_alt',
                'corporate.consent.google_maps.link',
                'corporate.consent.google_maps.button_info',
                'corporate.consent.google_maps.button_consent',
                'corporate.consent.google_maps.button_withdrawal',
                //google tag manager
                'corporate.consent.google_tag_manager.title',
                'corporate.consent.google_tag_manager.content',
                'corporate.consent.google_tag_manager.link',
                'corporate.consent.google_tag_manager.button_info',
                'corporate.consent.google_tag_manager.button_consent',
                'corporate.consent.google_tag_manager.button_reject',
                'corporate.consent.google_tag_manager.button_withdrawal',
                //openstreetmap
                'corporate.consent.openstreetmap.title',
                'corporate.consent.openstreetmap.content',
                'corporate.consent.openstreetmap.image',
                'corporate.consent.openstreetmap.image_alt',
                'corporate.consent.openstreetmap.link',
                'corporate.consent.openstreetmap.button_info',
                'corporate.consent.openstreetmap.button_consent',
                'corporate.consent.openstreetmap.button_withdrawal',
                //recaptcha
                'corporate.consent.recaptcha.content',
                'corporate.consent.recaptcha.link',
                'corporate.consent.recaptcha.button_withdrawal',
                //vimeo
                'corporate.consent.vimeo.title',
                'corporate.consent.vimeo.content',
                'corporate.consent.vimeo.image',
                'corporate.consent.vimeo.image_alt',
                'corporate.consent.vimeo.link',
                'corporate.consent.vimeo.button_info',
                'corporate.consent.vimeo.button_consent',
                'corporate.consent.vimeo.button_withdrawal',
                //youtube
                'corporate.consent.youtube.title',
                'corporate.consent.youtube.content',
                'corporate.consent.youtube.image',
                'corporate.consent.youtube.image_alt',
                'corporate.consent.youtube.link',
                'corporate.consent.youtube.button_info',
                'corporate.consent.youtube.button_consent',
                'corporate.consent.youtube.button_withdrawal',
                //usercentrics overlay
                'corporate.usercentrics.sdp.title',
                'corporate.usercentrics.sdp.content',
                'corporate.usercentrics.sdp.content_map',
                'corporate.usercentrics.sdp.content_video',
                'corporate.usercentrics.sdp.button_info',
                'corporate.usercentrics.sdp.button_consent',
                //usercentrics text
                'corporate.usercentrics.sdp.content_recaptcha',
                //usercentrics message
                'corporate.usercentrics.sdp.permission'
            ];

            //replace the field original with the translation if exist
            foreach ($translated_fields as $translated_field){
                $translated_field_name =  YooTranslateTransform::getTranslatedFieldName($translated_field,$currentLanguage);
                $translation =  $config('~theme.'.$translated_field_name);
                if (isset($translation) && !empty($translation)){
                    $config->set('~theme.'.$translated_field , $translation);
                }
            }

        }

    }
    /**
     * Transform callback.
     * Use for Front-end translation
     * @from 1.0
     * @update 1.19 add newsletter message and redirect translation
     * @update 1.39 add search system
     * @update 1.40 fix warning in search template
     * @update 1.41 add dj popup support
     * @update 2.1 fix missing getLanguage Method
     * @update 2.2 remove tempoary code set by error (check the  embeded source page)
     *
     * @param object $node
     * @param array  $params
     */
    public function __invoke($node, array $params)
    {
        /**
         * @var $type
         */
        extract($params);
        $languages = LanguageHelper::getLanguages('lang_code');
        $currentLanguage = $languages[Factory::getApplication()->getLanguage()->getTag()];
        $default_lang = ComponentHelper::getParams('com_languages')->get('site', 'en-GB');

        //search managed by filter yootheme_save_page see pageListener set a search and language to allow
        //indexing
        if (isset($params['search']) && $params['search'] ==  true){
            //fix notice in search template
            if (isset($params['lang'])){
                $locale = $params['lang'];
                $currentLanguage = $languages[$locale];
            }
        }


        if ($currentLanguage->lang_code == $default_lang ){
            return;
        }


        $elts = PlgSystemTranslateYooPro::getElements();
        //supported element translation
        if (isset($elts[$node->type])){
            foreach ($elts[$node->type]['fields'] as $field){
                $translated_field_name =  YooTranslateTransform::getTranslatedFieldName($field,$currentLanguage);

                if (isset($node->props[$translated_field_name]) && !empty($node->props[$translated_field_name])){
                    $node->props[$field] = $node->props[$translated_field_name];
                }
                //manage newsletter provider for message and rediret
                if ($node->type == 'newsletter' && ($field == 'provider.message' || $field == 'provider.redirect' )){
                    $translated_field_name = str_replace('provider.','',$translated_field_name);
                    $field = str_replace('provider.','',$field);
                    if (isset($node->props['provider']) && isset($node->props['provider']->{$translated_field_name}) && !empty($node->props['provider']->{$translated_field_name})){
                        $node->props['provider']->{$field} = $node->props['provider']->{$translated_field_name};
                    }
                }
            }
        }

        //DJ Popup support
        //wp-djpopup/modules/builder/src/Transform/SectionTransform.php
        //change the node type to djpopup
        if ($node->type == 'djpopup'){
            $translated_mfields = ['heading','save_text','save_link','cancel_text'];
            foreach ($translated_mfields as $translated_field){
                $translated_field_name =  YooTranslateTransform::getTranslatedFieldName($translated_field,$currentLanguage);
                if (isset($node->props['djpopup']->{$translated_field_name})){
                    //empty content display the original => no override
                    if (!empty($node->props['djpopup']->{$translated_field_name})){
                        $node->props['djpopup_'.$translated_field] = $node->props['djpopup']->{$translated_field_name};
                    }
                }
            }
        }

    }

    /**
     * Add extra field to each elements.
     * Use for backend  translation
     *
     * @param object $node
     * @param array  $params
     *
     * @since 1.9 allow source to be dynamic
     * @since 1.28 addd debounce to disabled refresh on content translation edition
     * @since 1.34 change debounce delay from 3000 to 500 (Fix save button display delay)
     */
    public static function initSource(array $type)
    {

        if (isset($type)){
            $elts = PlgSystemTranslateYooPro::getElements();
            if (isset($elts[$type['name']])){
                //get fileds to translate for this elements
                $fields = $elts[$type['name']]['fields'];
                $languages = YooTranslateTransform::getLanguages(false);
                $newFieldList = array();
                foreach ($languages as $language){
                    foreach ($fields as $field){
                        //check the field in case of extra elemnts change
                        if (!isset($type['fields'][$field])){continue;}
                        //add new fieldtype
                        $newFieldType = $type['fields'][$field];
                        //countdown don't have label define for hours, minutes... only days
                        //yooessential markdown too
                        //put empty label in this case
                        if (!isset($newFieldType['label'])) {$newFieldType['label'] = '';}

                        $newFieldType['label'] = YooTranslateTransform::getTranslatedFieldLabel($newFieldType['label'], $language);
                        if (isset($newFieldType['source'])) {
                            // $newFieldType['source'] = false;//need to be keep to allow dynamic
                        }
                        //change refresh for content (work only on content)
                        if ($field == 'content' ){
                            $newFieldType['attrs'] = ["debounce" => 500];
                        }

                        //add new fieldtype
                        $type['fields'][YooTranslateTransform::getTranslatedFieldName($field, $language)] = $newFieldType;

                        $newFieldList[] = YooTranslateTransform::getTranslatedFieldName($field, $language);

                        //add new field to Falang tab
                    }

                }
                $newfield = array('title'=> Text::_('PLG_TRANSLATEYOOPRO_TAB_NAME'),'fields' => $newFieldList);
                $type['fieldset']['default']['fields'][] = $newfield;
            }

            //display message on Lite version
            if(PlgSystemTranslateYooPro::isLite()){
                $elts_pro = PlgSystemTranslateYooPro::getProElements();
                if (isset($elts_pro[$type['name']])){
                    $fieldmessage['falang_pro_message'] = [
                        'label' => 'Falang Message',
                        'source' => false,
                        'type' => 'none',
                        'description' => 'The Falang for YOOTheme Pro is needed to translate this element.'
                    ];
                    $newfield = array('title'=> Text::_('PLG_TRANSLATEYOOPRO_TAB_NAME'),'fields' => $fieldmessage);
                    $type['fieldset']['default']['fields'][] = $newfield;
                }
            }

        }
        return $type;
    }

    /*
     * Return list of translated language
     * @since 1.1 add $only_published
     * @update 1.26 order the language by default asc
     *              fix bug if only_published is set
     * */
    public static function getLanguages($only_published = true){
        if($only_published){
            $languages = LanguageHelper::getContentLanguages( array(1), true, null, 'ordering', 'asc');
        } else {
            $languages = LanguageHelper::getContentLanguages( array(1,0), true, null, 'ordering', 'asc');
        }
        $default_lang = ComponentHelper::getParams('com_languages')->get('site', 'en-GB');
        //remove default language from $languages
        foreach ($languages as $i => $language) {
            if ($language->lang_code == $default_lang) {
                unset($languages[$i]);
                break;
            }
        }
        return $languages;
    }

    /**
     * get the internal name for the field ex content_fr_fr
     * @param $name
     * @param $language
     *
     * @return string
     * 	 */
    public static function getTranslatedFieldName($name, $language)
    {
        return $name . '_' . str_replace('-','_',strtolower($language->lang_code));
    }

    /**
     * get the internal name for the field label ex Content fr-FR (Joomla)
     * @param $name
     * @param $language
     *
     * @return string
     * 	 */
    public static function getTranslatedFieldLabel($name, $language)
    {
        return $name . ' ' . ($language->lang_code);
    }

    /**
     * get the internal name for the panel tab (no space , use -)
     *
     * @since 1.42
     * @param $name
     * @param $language
     *
     * @return string
     * 	 */
    public static function getTranslatedPanelTab($name, $language)
    {
        return $name . '-' . ($language->lang_code);
    }


}
