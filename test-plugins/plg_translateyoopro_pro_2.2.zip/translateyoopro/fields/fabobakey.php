<?php
/**
 * @package     Yootheme Pro Translate for Joomla!
 * @author      Stéphane Bouey <stephane.bouey@faboba.com> - http://www.faboba.com
 * @license     GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 * @copyright   Copyright (C) 2012-2024 Faboba. All rights reserved.
 * @source      JoomlaPro.com / Claes Norin
 */

use Joomla\CMS\Factory;
use Joomla\CMS\Form\Field\TextField;
use Joomla\CMS\Form\FormHelper;
use Joomla\CMS\Language\Text;
use Joomla\Database\DatabaseInterface;

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects


FormHelper::loadFieldClass('text');

class JFormFieldFabobakey extends TextField {

    protected $type = 'Fakey';

    protected $fieldname = 'Faboba_Key';

    /*
     * hide the label field
     * work for J4+
     * */
    protected $hiddenLabel = true;

    /*
     * no label on J3 / label not displayed on J4+
     *
     * */
   public function getLabel() {
      return '';
   }


   /*
    * @update 1.26 change message for J4 downloadID
    *              remove the margin J4 seem not necessary
    *
    * @update 2.0 change link my-downloadid.html is now my-licences.html
    *             remove code for Joomla 3
    * */
    public function getInput()
    {

        $db = Factory::getContainer()->get(DatabaseInterface::class);
        $query = $db->getQuery(true)
            ->select(array('e.extension_id', 'e.type', 'e.name', 'e.manifest_cache', 'us.update_site_id', 'us.enabled', 'us.extra_query'))
            ->from($db->quoteName('#__extensions', 'e'))
            ->join('LEFT OUTER', $db->quoteName('#__update_sites_extensions', 'use') . ' ON (' . $db->quoteName('e.extension_id') . ' = ' .
                $db->quoteName('use.extension_id') . ')')
            ->join('LEFT OUTER', $db->quoteName('#__update_sites', 'us') . ' ON (' . $db->quoteName('us.update_site_id') . ' = ' .
                $db->quoteName('use.update_site_id') . ')')
            ->where($db->quoteName('element') . ' = ' . $db->quote('translateyoopro'))
            ->where($db->quoteName('us.update_site_id') . ' IS NOT NULL');

        $db->setQuery($query);
        $component = $db->LoadObject();

        $update_site_id = $component->update_site_id;
        $msg = '';

        //display donwload id message on pro version
        if (!PlgSystemTranslateYooPro::isLite()) {
            if (version_compare(JVERSION, '4.0', 'ge')) {
                //Joomla 4+ Display link to update in update site
                $update_url = "index.php?option=com_installer&task=updatesite.edit&update_site_id=" . $update_site_id;
                $extension_update_url = 'index.php?option=com_installer&view=update';
                $msg = '<div class="alert alert-info">';
                $msg .= '<h3>You need to enter your Download ID</h3>';
                $msg .= '<p>You must enter your <a href="' . $update_url . '">Download Key here</a> before you can update this extension via Update <a href="' . $extension_update_url . '">Joomla Extension Update</a>.<br/></p>';
                $msg .= '<p><a href="https://www.faboba.com/en/my-licences.html" target="_blank">If you don\'t know your download ID, please click here</a></p>';
                $msg .= '</div>';
            }
        }

        $html[] = $msg;
        return implode("\n", $html);

    }

}
?>