<?php
/**
 * @package     Yootheme Pro Translate for Joomla!
 * @author      Stéphane Bouey <stephane.bouey@faboba.com> - http://www.faboba.com
 * @license     GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 * @copyright   Copyright (C) 2012-2024 Faboba. All rights reserved.
 */

use Joomla\CMS\Factory;
use Joomla\Filesystem\File;
use Joomla\Filesystem\Folder;
use Joomla\CMS\Log\Log;
use Joomla\Database\DatabaseInterface;

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

class plgSystemTranslateyooproInstallerScript
{
    protected $minimumPHPVersion = '8.0.0';
    protected $minimumJoomlaVersion = '5.0.0';
    protected $minimumYOOthemeVersion = '4.0.0';
    protected $maximumJoomlaVersion = '6.4.99';
    private $version = "Pro";

    private $removeProFile = array(
        'files'	=> array(
            'plugins/system/translateyoopro/elements/accordion_item.json',
            'plugins/system/translateyoopro/elements/alert.json',
            'plugins/system/translateyoopro/elements/breadcrumbs.json',
            'plugins/system/translateyoopro/elements/countdown.json',
            'plugins/system/translateyoopro/elements/description_list_item.json',
            'plugins/system/translateyoopro/elements/gallery.json',
            'plugins/system/translateyoopro/elements/gallery_item.json',
            'plugins/system/translateyoopro/elements/grid.json',
            'plugins/system/translateyoopro/elements/grid_item.json',
            'plugins/system/translateyoopro/elements/html.json',
            'plugins/system/translateyoopro/elements/icon.json',
            'plugins/system/translateyoopro/elements/image.json',
            'plugins/system/translateyoopro/elements/list_item.json',
            'plugins/system/translateyoopro/elements/map.json',
            'plugins/system/translateyoopro/elements/map_item.json',
            'plugins/system/translateyoopro/elements/nav_item.json',
            'plugins/system/translateyoopro/elements/newsletter.json',
            'plugins/system/translateyoopro/elements/overlay.json',
            'plugins/system/translateyoopro/elements/overlay-slider.json',
            'plugins/system/translateyoopro/elements/overlay-slider_item.json',
            'plugins/system/translateyoopro/elements/panel.json',
            'plugins/system/translateyoopro/elements/panel-slider.json',
            'plugins/system/translateyoopro/elements/panel-slider_item.json',
            'plugins/system/translateyoopro/elements/popover.json',
            'plugins/system/translateyoopro/elements/popover_item.json',
            'plugins/system/translateyoopro/elements/quotation.json',
            'plugins/system/translateyoopro/elements/section.json',
            'plugins/system/translateyoopro/elements/slideshow.json',
            'plugins/system/translateyoopro/elements/slideshow_item.json',
            'plugins/system/translateyoopro/elements/social_item.json',
            'plugins/system/translateyoopro/elements/subnav_item.json',
            'plugins/system/translateyoopro/elements/switcher.json',
            'plugins/system/translateyoopro/elements/switcher_item.json',
            'plugins/system/translateyoopro/elements/table.json',
            'plugins/system/translateyoopro/elements/table_item.json',
            'plugins/system/translateyoopro/elements/totop.json',
            'plugins/system/translateyoopro/elements/video.json',
        ),
        'folders' => array(
            'plugins/system/translateyoopro/elements/cloudfood/',
            'plugins/system/translateyoopro/elements/flart/',
            'plugins/system/translateyoopro/elements/forrestkirby/',
            'plugins/system/translateyoopro/elements/joomlapro/',
            'plugins/system/translateyoopro/elements/morejoomla/',
            'plugins/system/translateyoopro/elements/zoo/'
        )
    );

    private $removeOldFile = array(
        'files'	=> array(
            'plugins/system/translateyoopro/elements/flart/fs_load_more.json',
            'plugins/system/translateyoopro/elements/flart/fs_toggle.json',
        ),
        'folders' => array(
        )
    );

    public function install($parent)
    {
        // Enable the extension
        $this->enablePlugin();

        return true;
    }

    public function uninstall($parent)
    {
    }

    public function update($parent)
    {
    }

    public function preflight($type, $parent)
    {
        // Check the minimum PHP version
        if (!version_compare(PHP_VERSION, $this->minimumPHPVersion, '>='))
        {
            $msg = '<p>You need PHP ' . $this->minimumPHPVersion . ' or later to install this plugin.</p>';
            Log::add($msg, Log::WARNING, 'jerror');

            return false;
        }

        // Check the minimum Joomla! version
        if (!version_compare(JVERSION, $this->minimumJoomlaVersion, '>='))
        {
            $msg = '<p>You need Joomla! ' . $this->minimumJoomlaVersion . ' or later to install this plugin.</p>';
            Log::add($msg, Log::WARNING, 'jerror');

            return false;
        }

        // Check the minimum Joomla! version
        if( version_compare(JVERSION, $this->maximumJoomlaVersion, 'gt') ) {
            $msg = '<p>You need a Joomla version between ' . $this->minimumJoomlaVersion . ' and ' . $this->maximumJoomlaVersion . ' to install this plugin.</p>';
            Log::add($msg, Log::WARNING, 'jerror');

            return false;
        }

        // Check the minimum YOOtheme Pro version
        $yoothemeManifest = simplexml_load_file(JPATH_SITE . '/templates/yootheme/templateDetails.xml');
        if (!$yoothemeManifest or !version_compare((string) $yoothemeManifest->version, $this->minimumYOOthemeVersion, '>='))
        {
            $msg = '<p>You need YOOtheme Pro ' . $this->minimumYOOthemeVersion . ' or later to install this plugin.</p>';
            Log::add($msg, Log::WARNING, 'jerror');

            return false;
        }

        return true;
    }

    /*
     * @from 1.0
     * @updaqte 1.18 remove Pro file when installing Lite
     * @update 1.40 remove old file and folder
     * */
    public function postflight($type, $parent)
    {
        $isLite = strtolower($this->version) == 'lite'? true:false;

        if ($isLite){
            $this->_removeFilesAndFolders($this->removeProFile);
        }

        $this->_removeFilesAndFolders($this->removeOldFile);

        $this->_removeUpdateSiteFromOtherVersion($isLite);
    }

    private function enablePlugin()
    {
        try
        {
            $db    = Factory::getContainer()->get(DatabaseInterface::class);
            $query = $db->getQuery(true)
                        ->update('#__extensions')
                        ->set($db->qn('enabled') . ' = ' . $db->q(1))
                        ->where('type = ' . $db->quote('plugin'))
                        ->where('folder = ' . $db->quote('system'))
                        ->where('element = ' . $db->quote('translateyoopro'));
            $db->setQuery($query);
            $db->execute();
        }
        catch (\Exception $e)
        {
            return;
        }
    }

    /**
     * Removes File/Folder from array or files and folders
     * @from 1.18
     *
     * @param array $filesAndFolders
     */
    private function _removeFilesAndFolders($filesAndFolders){
        // Remove files
        if(!empty($filesAndFolders['files'])) foreach($filesAndFolders['files'] as $file) {
            $f = JPATH_ROOT.'/'.$file;
            if(!File::exists($f)) continue;
            File::delete($f);
        }

        // Remove folders
        if(!empty($filesAndFolders['folders'])) foreach($filesAndFolders['folders'] as $folder) {
            $f = JPATH_ROOT.'/'.$folder;
            if(!Folder::exists($f)) continue;
            Folder::delete($f);
        }

    }

    /**
     * Removes update site from other Translate for yootheme version fix 403 on update
     * @from 1.18
     */
    private function _removeUpdateSiteFromOtherVersion($isLite)
    {
        $db = Factory::getContainer()->get(DatabaseInterface::class);
        $query = $db->getQuery(true)
            ->delete($db->qn('#__update_sites'));

        if ($isLite){
            $xml_to_keep = 'https://www.faboba.com/update/translateyoolite/translateyoolite.xml';
            $query->where($db->qn('location').' = '.$db->q('https://www.faboba.com/update/translateyoopro/translateyoopro.xml'));
        } else {
            $xml_to_keep = 'https://www.faboba.com/update/translateyoopro/translateyoopro.xml';
            $query->where($db->qn('location').' = '.$db->q('https://www.faboba.com/update/translateyoolite/translateyoolite.xml'));
        }
        // Delete the #__update_sites record
        $db->setQuery($query);
        try {
            $db->execute();
        } catch (Exception $exc) {
            // If the query fails, don't sweat about it
        }

    }

}
