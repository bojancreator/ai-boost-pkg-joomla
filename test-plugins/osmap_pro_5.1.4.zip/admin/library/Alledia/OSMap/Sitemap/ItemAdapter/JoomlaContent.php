<?php

/**
 * @package   OSMap-Pro
 * @contact   www.joomlashack.com, help@joomlashack.com
 * @copyright 2007-2014 XMap - Joomla! Vargas - Guillermo Vargas. All rights reserved.
 * @copyright 2016-2025 Joomlashack.com. All rights reserved
 * @license   https://www.gnu.org/licenses/gpl.html GNU/GPL
 *
 * This file is part of OSMap-Pro.
 *
 * OSMap-Pro is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * OSMap-Pro is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OSMap-Pro.  If not, see <https://www.gnu.org/licenses/>.
 */

namespace Alledia\OSMap\Sitemap\ItemAdapter;

use Alledia\OSMap\Factory;
use Joomla\Registry\Registry;

// phpcs:disable PSR1.Files.SideEffects.FoundWithSymbols
defined('_JEXEC') or die();

// phpcs:enable PSR1.Files.SideEffects.FoundWithSymbols

abstract class JoomlaContent extends GenericPro
{
    /**
     * @var string
     */
    protected string $tableName = '#__table_name';

    /**
     * @inheritDoc
     */
    protected function getRobotsSettings(): string
    {
        $db = Factory::getDatabase();

        // Get the robots params from the row
        $query = $db->getQuery(true)
            ->select('metadata')
            ->from($db->quoteName($this->tableName))
            ->where($db->quoteName('id') . '=' . (int)$this->item->id);

        $row = $db->setQuery($query)->loadObject();
        if ($row !== null) {
            $metadata = new Registry($row->metadata);

            $this->robots = $metadata->get('robots');
        }

        // There is no params, so use the defaults
        if (empty($this->robots)) {
            parent::getRobotsSettings();
        }

        return $this->robots;
    }
}
