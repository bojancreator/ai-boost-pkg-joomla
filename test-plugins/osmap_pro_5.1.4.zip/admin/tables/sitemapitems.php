<?php

/**
 * @package   OSMap
 * @contact   www.joomlashack.com, help@joomlashack.com
 * @copyright 2007-2014 XMap - Joomla! Vargas - Guillermo Vargas. All rights reserved.
 * @copyright 2016-2025 Joomlashack.com. All rights reserved.
 * @license   https://www.gnu.org/licenses/gpl.html GNU/GPL
 *
 * This file is part of OSMap.
 *
 * OSMap is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * OSMap is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with OSMap.  If not, see <https://www.gnu.org/licenses/>.
 */

use Joomla\CMS\Table\Table;

// phpcs:disable PSR1.Files.SideEffects.FoundWithSymbols
defined('_JEXEC') or die();
// phpcs:enable PSR1.Files.SideEffects.FoundWithSymbols
// phpcs:disable PSR1.Classes.ClassDeclaration.MissingNamespace

class OSMapTableSitemapItems extends Table
{
    /**
     * @var int Primary key
     */
    public $sitemap_id = null;

    /**
     * @var string
     */
    public $uid = null;

    /**
     * @var int
     */
    public $published = null;

    /**
     * @var string
     */
    public $changefreq = 'weekly';

    /**
     * @var int
     */
    public $priority = 5;

    /**
     * @inheritDoc
     */
    public function __construct($db)
    {
        parent::__construct('#__osmap_items_settings', ['sitemap_id', 'uid', 'settings_hash'], $db);
    }
}
