<?php

/**
 * @package         Tassos Code Snippets
 * @version         1.0.0 Pro
 * 
 * @author          Tassos Marinos <info@tassos.gr>
 * @link            http://www.tassos.gr
 * @copyright       Copyright © 2018 Tassos Marinos All Rights Reserved
 * @license         GNU GPLv3 <http://www.gnu.org/licenses/gpl.html> or later
*/

defined('_JEXEC') or die('Restricted access');

extract($displayData);
?>
<input type="hidden" name="<?php echo $name; ?>[unit]" class="tf-unit-control-unit-value" value="<?php echo $unit; ?>" />