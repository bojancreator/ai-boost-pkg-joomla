<?php

/**
 * @author          Tassos.gr
 * @link            https://www.tassos.gr
 * @copyright       Copyright © 2024 Tassos All Rights Reserved
 * @license         GNU GPLv3 <http://www.gnu.org/licenses/gpl.html> or later
*/

namespace Tassos\Framework\Conditions\Conditions\Component;

defined('_JEXEC') or die;

class SPPageBuilderCategory extends SPPageBuilderBase
{
    /**
     * Shortcode aliases for this Condition
     */
    public static $shortcode_aliases = ['sppagebuilder.category'];

    /**
     *  Pass check
     *
     *  @return bool
     */
    public function pass()
    {
        return $this->passCategories('categories', 'parent_id');
	}

}